Hide OllyDBG Plugin V1.02

Functions:
1.Hide IsDebuggerPresent
2.Hide NtGlobalFlag
3.Hide ProcessHeapFlag
4.Patch ZwQueryInformationProcess (==patch UnhandledExceptionFilter)
5.Patch ZwSetInformationThread
6.Patch CheckRemoteDebuggerPresent
7.Patch OutputDebugStringA
8.Anti heap-checking (For themida1.9.5.0)

V1.02:
! Fixed the bug of patching ZwSetInformationThread (For themida 1.9.5.0)
+ ADD heap-checking.

Debug themida1.9.5
1.Modify window caption in the file ollydbg.exe (CPU,OLLYDBG...)
2.Click "Hide ALL" (choose HideDBG plugin)