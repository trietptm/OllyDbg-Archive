# OllyDbg-v1.10-With-Best-Plugins-And-Immunity-Debugger-theme-
Make OllyDbg v1.10 Look like Immunity Debugger &amp; Best Plugins


![alt tag](https://github.com/romanzaikin/OllyDbg-v1.10-With-Best-Plugins-And-Immunity-Debugger-theme-/blob/master/ollydbg.JPG)

```plugin list```

- StrongOD v0.4.8.892
- PhantOm Plugin v1.85
- OllyStepNSearch v0.6.2
- OllyDump v3.00.110
- EasyController v1.0.5.0
- Analyze This v0.1

```before using update the ini file to match the location of the project```

![alt tag](https://raw.githubusercontent.com/romanzaikin/OllyDbg-v1.10-With-Best-Plugins-And-Immunity-Debugger-theme-/master/odbg%20place.JPG)


Configuration
==========================
1) Downlaod the zip file or clone.

2) Extract the file to C:\OllyDbg (or any other place you want).

3) Open ollydbg.ini.

4) Replace all "C:\new odbg110" to your Extract path "C:\OllyDbg".

5) Run OLLYDBG.EXE and have a Happy reversing.


Thanks :)
