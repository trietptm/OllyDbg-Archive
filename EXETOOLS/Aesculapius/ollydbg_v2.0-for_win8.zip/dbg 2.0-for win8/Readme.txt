OllyPortable is my portable version of OllyDbg extended with plugins and patches for a good looking and decently working debugger environment.

Main features:
- Good looking buttons (thanks to the author of Olly Shadow)
- Full portability (OllyPath.dll, source is included)
- Tested & working on both XP SP3 and Win7 x64
- Manifest to make olly look less Win98
- Useful plugins, sometimes with custom patches

Plugin descriptions:
- analyzeThis: Analyze code outside the code section of the debugged program.
- Asm2Clipboard: Quickly copy ASM code (with labels) to the clipboard.
- ClearUDD: Plugin to clear the UDD directory from within olly.
- CmdBar: Command bar to quickly set breakpoints/registers etc.
- DataRipper: Rip selected data in various formats.
- HiddenThreads: Plugin that finds hidden threads.
- ICanAttach2: Plugin that fixed anti-attach tricks.
- ida_sigs: Plugin to import IDA signatures to the debugged file.
- IDAFicator: Great plugin with many features, check the manual.
- MnemonicHelp: Simply plugin that loads a help file for the selected mnemonic.
- ModuleBCL: Import&Export labels, comments and breakpoints.
- multiasm_odbg: Extremely useful plugin for writing code caves.
- ODbgScript: Script OllyDbg (Patched by me)
- ODBJscript: Script OllyDbg using javascript
- oDump: Fixed version of OllyDump that bypasses anti-dump techniques.
- OllyCopy: Great plugin to copy addresses, bytes and patterns to the clipboard.
- OllyFlow: Generate an IDA graph from analyzed code.
- OllyWow64_0.2: Compatibility plugin for WOW64
- RemoveCriticality: Plugin that fixes an exploit that could crash the system when debugging.
- SehSpy: Show the SEH context before the reached exception.
- SigMaker: Easily make patterns and signatures.
- StollyStruct: Plugin that allows viewing memory in structure form (Patched by me)
- StrongOD: Hide & Bugfix plugin (Patched by me)
- TLSCatch: Plugin that sets a breakpoint on TLS callbacks (when found)
- X_CRYPTO: Plugin to hash bytes or text inside olly.

I also included the help files for ODbgScript, ODBJScript, Multiasm, Win32 API and x86 opcodes.

Enjoy,

Mr. eXoDia