For general information see

    Documentation\README.txt

For information on and example breakpoint sets see:

    Breakpoints Sets\README.txt
