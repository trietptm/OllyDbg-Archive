__________.__     _____          __    
\______   \  |   / ___ \   ____ |  | __
 |    |  _/  |  / / ._\ \_/ ___\|  |/ /
 |    |   \  |_<  \_____/\  \___|    < 
 |______  /____/\_____\   \___  >__|_ \
        \/                    \/     \/
  _________ __   _______           _____   
 /   _____//  |_ \   _  \_______  /     \  
 \_____  \\   __\/  /_\  \_  __ \/  \ /  \ 
 /        \|  |  \  \_/   \  | \/    Y    \
/_______  /|__|   \_____  /__|  \____|__  /
        \/              \/              \/ 
__________            ________               ____         ________
\______   \ _______  _\_____  \______  _____/_   | ____  /  _____/
 |       _// __ \  \/ / _(__  <_  __ \/  ___/|   |/    \/   __  \ 
 |    |   \  ___/\   / /       \  | \/\___ \ |   |   |  \  |__\  \
 |____|_  /\___  >\_/ /______  /__|  /____  >|___|___|  /\_____  /
        \/     \/            \/           \/          \/       \/ 

Description:
Anti Anti and compatibility plugin for Olly 1.10 running on Vista x64.
I made this little plugin to make unpacking on Vista x64 a bit more bearable ;)
It has most of the know anti anti and makes an effort to make Olly behave like it should on regular x86 machines.
Next to this I implemented my own version of the OllyBone 'Break On Execute' making unpacking some simple packers a lot easier. 

Enjoy.
revert
