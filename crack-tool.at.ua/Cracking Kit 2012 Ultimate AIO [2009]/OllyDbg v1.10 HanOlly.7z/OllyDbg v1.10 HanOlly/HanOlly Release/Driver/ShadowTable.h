PVOID getDebugPort();
BOOL exists(DWORD pid);