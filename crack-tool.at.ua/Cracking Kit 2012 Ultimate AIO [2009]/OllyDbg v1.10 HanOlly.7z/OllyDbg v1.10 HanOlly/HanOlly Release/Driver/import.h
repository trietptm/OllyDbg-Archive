#ifndef _import_h
#define _import_h

#define VER_PRODUCTBUILD 2600
#include "ntifs.h"
#include <windef.h>
#include "DefDatabase.h"
#include "Api.h"
#include "Hook.h"
#include "main.h"
#include "Core.h"
#include "ShadowTable.h"

#endif