#include "import.h"

NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject, IN PUNICODE_STRING RegistryPath)
{
    NTSTATUS        ntStatus;
    UNICODE_STRING  uszDriverString;
    UNICODE_STRING  uszDeviceString;
	PDEVICE_OBJECT  pDeviceObject;
	PVOID callback;

	RtlInitUnicodeString(&uszDriverString, L"\\Device\\HanOlly");

    ntStatus = IoCreateDevice(DriverObject, 0, &uszDriverString, FILE_DEVICE_UNKNOWN, 0, FALSE, &pDeviceObject);

    if(ntStatus != STATUS_SUCCESS)
        return ntStatus;

	RtlInitUnicodeString(&uszDeviceString, L"\\DosDevices\\HanOlly");

    ntStatus = IoCreateSymbolicLink(&uszDeviceString, &uszDriverString);

    if(ntStatus != STATUS_SUCCESS)
    {
        IoDeleteDevice(pDeviceObject);
        return ntStatus;
    }
    DriverObject->DriverUnload                         = MSJUnloadDriver;
    DriverObject->MajorFunction[IRP_MJ_CREATE]         = MSJDispatchCreate;
    DriverObject->MajorFunction[IRP_MJ_CLOSE]          = MSJDispatchClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = MSJDispatchIoctl;

	ini();
	
    return ntStatus;
}

NTSTATUS MSJDispatchCreate(IN PDEVICE_OBJECT DeviceObject,
                       IN PIRP Irp)
{
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information=0;

    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return(STATUS_SUCCESS);
}


NTSTATUS MSJDispatchClose(IN PDEVICE_OBJECT DeviceObject,
                       IN PIRP Irp)
{
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information=0;

    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return(STATUS_SUCCESS);
}


NTSTATUS MSJDispatchIoctl(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
    NTSTATUS Status=STATUS_SUCCESS;
    PIO_STACK_LOCATION     irpStack = IoGetCurrentIrpStackLocation(Irp);

    switch(irpStack->Parameters.DeviceIoControl.IoControlCode)
    {

	}

    Irp->IoStatus.Status = Status;
    
    if(Status == STATUS_SUCCESS)
        Irp->IoStatus.Information = irpStack->Parameters.DeviceIoControl.OutputBufferLength;
    else
        Irp->IoStatus.Information = 0;

    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return Status;
}


void MSJUnloadDriver(PDRIVER_OBJECT DriverObject)
{
	UNICODE_STRING  uszDeviceString;
	unload();
	IoDeleteDevice(DriverObject->DeviceObject);
	RtlInitUnicodeString(&uszDeviceString, L"\\DosDevices\\HanOlly");
	IoDeleteSymbolicLink(&uszDeviceString);
}