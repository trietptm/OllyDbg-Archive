#include "import.h"

DWORD processID;
extern DWORD count;

DWORD pidList[50];

void addToList(DWORD pid)
{
	int i = 0;

	for(i = 0; i < 50; i++)
	{
		if(pidList[i] == 0)
		{
			pidList[i] = pid;
			break;
		}
		else if(pidList[i] == pid)
		{
			pidList[i] = 0;
			break;
		}
	}
}

BOOL exists(DWORD pid)
{
	int i;

	for(i = 0; i < 50; i++)
	{
		if(pidList[i] == pid)
			return TRUE;
	}
	return FALSE;
}

DWORD debugPort(DWORD pid)
{ /* 0 = Failure, 1 = Success */
	PEPROCESS target;
	NTSTATUS status;

	addToList(pid);
	return 1;
}

PVOID getDebugPort()
{
	return &debugPort;
}