#pragma once

typedef struct JMPHOOK
{
	BOOL inUse;
	DWORD address;
	char* functionName;
	PVOID trampoline;
	PVOID savedBytes;
} JMPHOOK, *PJMPHOOK;

NTSTATUS loadCallbacks();
NTSTATUS setHook(DWORD address, char* functionName, DWORD hookFunction, DWORD bytes);
DWORD getTrampoline(char* functionName);
NTSTATUS unhook(char* functionName);
DWORD getIndex(char* functionName);

VOID ImageCallback(PUNICODE_STRING FullImageName, HANDLE ProcessId, PIMAGE_INFO ImageInfo);
VOID zeroTable();