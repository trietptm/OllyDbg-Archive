#include <windows.h>
#include "api.h"

HINSTANCE hinst;
PVOID createprocTrampoline, createprocSaved;
typedef bool (WINAPI* CreateProcess_r)(LPCTSTR, LPTSTR, LPSECURITY_ATTRIBUTES, LPSECURITY_ATTRIBUTES, BOOL, DWORD, LPVOID, LPCTSTR, LPSTARTUPINFO, LPPROCESS_INFORMATION);
DWORD oldPid;

BOOL WriteRelativeInconditionalJmp(DWORD Address, DWORD JumpTo)
{
	DWORD oldProtect;
	MEMORY_BASIC_INFORMATION mbi;
	int varsize = sizeof(MEMORY_BASIC_INFORMATION);
	PVOID virtualQuery = VirtualQuery;
	PVOID virtualProtect = VirtualProtect;

	DWORD returnValue;

	__asm
	{
		push varsize
		lea eax, mbi
		push eax
		push Address
		mov eax, virtualQuery
		call eax                ; Call VirtualQuery

		lea eax, oldProtect
		push eax
		push 0x40
		push mbi.RegionSize
		push mbi.BaseAddress
		mov eax, virtualProtect
		call eax                 ; Call Virtual Protect
		mov returnValue, eax
	}

	if(IsBadWritePtr((PVOID)Address, 5) || IsBadReadPtr((PVOID)Address, 5) ||IsBadCodePtr((FARPROC)Address))
	{ return false; }

	__asm 
	{
		mov eax, Address    ; Copy Memory
		mov [eax], 0xe9
		mov eax, JumpTo
		sub eax, Address
		sub eax, 5
		mov ebx, eax
		mov eax, Address
		add eax, 1
		mov [eax], ebx
	}

	return true;
}

BOOL WINAPI CreateProcessHook(LPCTSTR lpApplicationName, LPTSTR lpCommandLine, LPSECURITY_ATTRIBUTES lpProcessAttributes, LPSECURITY_ATTRIBUTES lpThreadAttributes, BOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment, LPCTSTR lpCurrentDirectory, LPSTARTUPINFO lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation)
{
	DWORD reg1;
	DWORD reg2;
	DWORD reg3;
	DWORD reg4;
	DWORD pid;
	bool success;

	__asm push ebx
	__asm mov reg2, ecx
	__asm mov reg3, edx
	__asm mov reg4, esp
	CreateProcess_r functionReturn = (CreateProcess_r)createprocTrampoline;
	success = functionReturn(lpApplicationName, lpCommandLine, lpProcessAttributes, lpThreadAttributes, bInheritHandles, dwCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo, lpProcessInformation);
	pid = lpProcessInformation->dwProcessId;
	
	__asm mov eax, oldPid
	__asm push eax
	__asm xor eax, eax
	__asm push eax
	__asm mov eax, 0x2000
	__asm mov edx, 0x7ffe0300
	__asm call dword ptr [edx]

	oldPid = pid;
	__asm mov eax, pid
	__asm push eax
	__asm xor eax, eax
	__asm push eax
	__asm mov eax, 0x2000
	__asm mov edx, 0x7ffe0300
	__asm call dword ptr [edx]

	__asm mov ebx, reg1
	__asm mov ecx, reg2
	__asm mov edx, reg3
	__asm mov esp, reg4
	__asm pop ebx
	return success;
}

/*
void thread()
{
	DWORD pid = GetCurrentProcessId();
	FindWindow(NULL, NULL);
	while(true)
	{
		__asm mov eax, pid
		__asm push eax
		__asm xor eax, eax
		__asm push eax
		__asm mov eax, 0x2000
		__asm mov edx, 0x7ffe0300
		__asm call dword ptr [edx]
		Sleep(100);
	}
}
*/

int __stdcall DllMain(HINSTANCE hinstance, DWORD fdwReason, LPVOID)	
{
	DWORD bytes;
	BYTE entry;
	PVOID address = GetProcAddress(GetModuleHandle("Kernel32.dll"), "CreateProcessA");

	switch (fdwReason)
	{
		case DLL_PROCESS_ATTACH:
			hinst = hinstance;
			loadDriverEx("HanOlly");
			CopyMemory(&entry, address, 1);

			if(entry == 0x55)
				bytes = 6;
			else if(entry == 0x8B)
				bytes = 5;
		
			createprocTrampoline = VirtualAlloc(NULL, 10, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
			createprocSaved = VirtualAlloc(NULL, 5, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
			CopyMemory(createprocSaved, address, 5);
			CopyMemory(createprocTrampoline, address, 5);
			WriteRelativeInconditionalJmp((DWORD)createprocTrampoline + 5, (DWORD)address + 5);
			WriteRelativeInconditionalJmp((DWORD)address, (DWORD)CreateProcessHook);

			break;
		case DLL_PROCESS_DETACH:
			__asm mov eax, oldPid
			__asm push eax
			__asm xor eax, eax
			__asm push eax
			__asm mov eax, 0x2000
			__asm mov edx, 0x7ffe0300
			__asm call dword ptr [edx]
			ExitProcess(1);
	}
	return true;
}
