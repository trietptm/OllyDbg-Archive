diablo2oo2's Ollydbg
********************

[install]

 1. extract the archive
 
 2. run "lbr68.exe"
 