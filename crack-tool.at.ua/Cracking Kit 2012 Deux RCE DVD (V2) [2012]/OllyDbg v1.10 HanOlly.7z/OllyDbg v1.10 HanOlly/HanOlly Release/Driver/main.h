void MSJUnloadDriver(PDRIVER_OBJECT DriverObject);
NTSTATUS MSJDispatchCreate(IN PDEVICE_OBJECT DeviceObject,  IN PIRP Irp);
NTSTATUS MSJDispatchClose(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
NTSTATUS MSJDispatchIoctl(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);