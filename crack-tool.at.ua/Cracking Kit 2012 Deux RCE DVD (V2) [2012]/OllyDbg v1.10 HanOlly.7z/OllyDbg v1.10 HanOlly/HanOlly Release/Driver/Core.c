#include "import.h"

PSERVICE_DESCRIPTOR_TABLE SDTShadow;
PVOID InitServiceTable[20];
UCHAR InitArgumentTable[20];
PVOID InitCounterTable[20];

extern DWORD processID;

NTSTATUS ini()
{	
	NTSTATUS status;
	PEPROCESS linkProcess = NULL;

	SDTShadow = GetSDTShadowFromProcess();

	if(SDTShadow != NULL)
	{
		InitServiceTable[0]   = getDebugPort();
		InitArgumentTable[0]  = 4;

		__try 
		{
			linkProcess = LinkReferenceProcessByName("Explorer.exe");
			if(linkProcess)
			{
				KeAttachProcess(linkProcess);
				SDTShadow[2].ServiceTable     = (PVOID)InitServiceTable;
				SDTShadow[2].ArgumentTable    = (PVOID)InitArgumentTable;
				SDTShadow[2].TableSize        = 20;
				SDTShadow[2].CounterTable     = (PULONG)InitCounterTable;
				KeDetachProcess();
			}
		}
		__except(1)
		{ ; }
	}

	zeroTable();
	setHook((DWORD)KeServiceDescriptorTable[0].ServiceTable[0x9A], "NtQueryInformationProcess", (DWORD)NtQueryInformationProcessHook, 5);

	return STATUS_SUCCESS;
}

NTSTATUS unload()
{
	PSERVICE_DESCRIPTOR_TABLE SDTShadow2 = GetSDTShadowFromProcess();

	unhook("NtQueryInformationProcess");

	KeAttachProcess(LinkReferenceProcessByName("Explorer.exe"));
	SDTShadow2[2].ServiceTable = NULL;
	SDTShadow2[2].ArgumentTable = NULL;
	SDTShadow2[2].TableSize = 0;
	SDTShadow2[2].CounterTable = NULL;
	KeDetachProcess();

	return STATUS_SUCCESS;
}

NTSTATUS WINAPI NtQueryInformationProcessHook(HANDLE ProcessHandle, PROCESSINFOCLASS ProcessInformationClass, PVOID ProcessInformation, ULONG ProcessInformationLength, PULONG ReturnLength)
{	
	TNtQueryInformationProcss origonalFunction = (TNtQueryInformationProcss)getTrampoline("NtQueryInformationProcess");
	PEPROCESS currentProcess = PsGetCurrentProcess();

	if(exists(currentProcess->UniqueProcessId))
	{
		if(ProcessInformationClass == 7)
		{
			origonalFunction(ProcessHandle, ProcessInformationClass, ProcessInformation, ProcessInformationLength, ReturnLength);
			if(MmIsAddressValid(ProcessInformation))
				currentProcess->DebugPort = NULL;
		}
	}
	return origonalFunction(ProcessHandle, ProcessInformationClass, ProcessInformation, ProcessInformationLength, ReturnLength);

}