PEPROCESS LinkReferenceProcessByName(LPSTR ProcessName);
PVOID GetSDTShadowFromProcess();
BOOL WriteRelativeInconditionalJmp(DWORD AddressToChange, DWORD JumpTo);