#include "import.h"

DWORD base = 0, end = 0;
BOOL startSearching = FALSE;
JMPHOOK hookTable[500];

VOID zeroTable()
{
	RtlZeroMemory(&hookTable, sizeof(JMPHOOK) * 500);
}
NTSTATUS loadCallbacks()
{
	PsSetLoadImageNotifyRoutine((PLOAD_IMAGE_NOTIFY_ROUTINE)ImageCallback);
	return STATUS_SUCCESS;
}

VOID ImageCallback(PUNICODE_STRING FullImageName, HANDLE ProcessId, PIMAGE_INFO ImageInfo)
{
	DbgPrint("Loading Image -> %ws", FullImageName->Buffer);
	if(wcswcs(FullImageName->Buffer, L"dump_wmimmc.sys")) //Loading NProtect Driver
	{
		base = (DWORD)ImageInfo->ImageBase; //Base Address of Driver
		end = base + (DWORD)ImageInfo->ImageSize; //Last Address of Driver
		startSearching = TRUE; //Let Program Know Driver Has Been Loaded
	}
	return;
}

DWORD getIndex(char* functionName)
{
	char searchingName[MAX_PATH];
	char matchName[MAX_PATH];
	DWORD i = 0;

	strcpy((char*)&searchingName, functionName);

	for(i = 0; i < 500; i++)
	{
		if(hookTable[i].functionName != NULL)
		{
			strcpy((char*)&matchName, hookTable[i].functionName);
			if(_stricmp(matchName, searchingName) == 0)
				return i;
		}
	}

	return 501;
}

DWORD getTrampoline(char* functionName)
{
	DWORD index = getIndex(functionName);
	if(index < 500)
		return (DWORD)hookTable[index].trampoline;
	return 0;
}

NTSTATUS unhook(char* functionName)
{
	DWORD index = getIndex(functionName);

	if(index > 500)
		return STATUS_UNSUCCESSFUL;

	hookTable[index].inUse = FALSE;
	RtlCopyMemory((PVOID)hookTable[index].address, hookTable[index].savedBytes, 5);
	ExFreePool(hookTable[index].trampoline);
	ExFreePool(hookTable[index].savedBytes);
	hookTable[index].trampoline = NULL;
	hookTable[index].savedBytes = NULL;
	hookTable[index].address = 0;
	hookTable[index].functionName = NULL;
	
	return STATUS_SUCCESS;
}

NTSTATUS setHook(DWORD address, char* functionName, DWORD hookFunction, DWORD bytes)
{
	int i;

	for(i = 0; i < 500; i++)
	{
		if(hookTable[i].inUse == FALSE)
			break;
	}

	if(i == 500)
		return STATUS_UNSUCCESSFUL;

	hookTable[i].inUse = TRUE;
	hookTable[i].address = address;
	hookTable[i].functionName = functionName;
	hookTable[i].savedBytes = ExAllocatePool(NonPagedPool, bytes);
	hookTable[i].trampoline = ExAllocatePool(NonPagedPool, bytes + 5);

	RtlCopyMemory(hookTable[i].savedBytes, (PVOID)hookTable[i].address, bytes);
	RtlCopyMemory(hookTable[i].trampoline, (PVOID)hookTable[i].address, bytes);
	WriteRelativeInconditionalJmp(address, hookFunction);
	WriteRelativeInconditionalJmp((DWORD)hookTable[i].trampoline + bytes, address + bytes);

	return STATUS_SUCCESS;
}