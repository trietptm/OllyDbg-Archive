#include "import.h"

/*************************************************
 *                  Unrealord                    *
 *************************************************/

typedef enum _KAPC_ENVIRONMENT{
OriginalApcEnvironment,
AttachedApcEnvironment,
CurrentApcEnvironment
}KAPC_ENVIRONMENT;

PVOID GetPsActiveProcessHead()
{
	PVOID PsAPH;
	__asm
	{
		mov eax, 00ffdff034h
		mov eax, [eax]
		mov eax, [eax+78h]
		mov PsAPH, eax
	}
	return PsAPH;
}

PVOID GetPspCidTable()
{
	PVOID* PspCT;
	__asm 
	{
		mov eax, 00ffdff034h
		mov eax, [eax]
		mov eax, [eax+80h]
		mov PspCT, eax
	}
	return *PspCT;
}

PEPROCESS LinkReferenceProcessByName(LPSTR ProcessName)
{
	KIRQL OldIrql;
	KSPIN_LOCK SpinLock;
	PLIST_ENTRY ListHead;
	PLIST_ENTRY CurrentNode;
	PLIST_ENTRY PsActiveProcessHead;
	BOOL Found=FALSE;
	PEPROCESS CurrentProcess;
	PEPROCESS FoundProcess;
	PsActiveProcessHead=GetPsActiveProcessHead();
	if(PsActiveProcessHead==NULL)
		return NULL;
	ListHead=PsActiveProcessHead;
	CurrentNode=ListHead->Flink;
	KeInitializeSpinLock(&SpinLock);
	KeAcquireSpinLock(&SpinLock, &OldIrql);
	while(CurrentNode!=ListHead)
	{
		CurrentProcess=CONTAINING_RECORD(CurrentNode, EPROCESS, ActiveProcessLinks);
	
		if(_stricmp(PsGetProcessImageFileName(CurrentProcess), ProcessName)==0)
		{
			FoundProcess=CurrentProcess;
			Found=TRUE;
			break;
		}
		CurrentNode=CurrentNode->Flink;
	}
	KeReleaseSpinLock(&SpinLock, OldIrql);
	if(!Found)
		return NULL;
	return FoundProcess;
}

PVOID GetPsLoadedModuleList()
{
	PVOID PsLML;
	__asm 
	{
		mov eax, 00ffdff034h
		mov eax, [eax]
		mov eax, [eax+70h]
		mov PsLML, eax
	}
	return PsLML;
}

PVOID GetSDTShadowFromProcess()
{
	KSPIN_LOCK SpinLock;
	KIRQL OldIrql;
	PLIST_ENTRY ListHead;
	PLIST_ENTRY CurrentNode;
	PLIST_ENTRY TListHead;
	PLIST_ENTRY TCurrentNode;
	PEPROCESS CurrentProcess;
	PETHREAD CurrentThread;
	PVOID SDTShadow;
	BOOL SDTFound = FALSE;

	ListHead = GetPsActiveProcessHead();

	if(!ListHead)
		return NULL;

	CurrentNode = ListHead->Flink;
	KeInitializeSpinLock(&SpinLock);
	KeAcquireSpinLock(&SpinLock, &OldIrql);

	while(CurrentNode != ListHead)
	{
		CurrentProcess = CONTAINING_RECORD(CurrentNode, EPROCESS, ActiveProcessLinks);
		TListHead = &CurrentProcess->ThreadListHead;

		if(!TListHead)
		{
			CurrentNode=CurrentNode->Flink;
			continue;
		}

		TCurrentNode = TListHead->Flink;

		while(TListHead != TCurrentNode)
		{
			CurrentThread = CONTAINING_RECORD(TCurrentNode, ETHREAD, ThreadListEntry);

			if(!CurrentThread)
			{
				TCurrentNode = TCurrentNode->Flink;
				continue;
			}

			if(MmIsAddressValid(&CurrentThread->Tcb.ServiceTable))
			{
				if(CurrentThread->Tcb.ServiceTable != KeServiceDescriptorTable)
				{
					SDTShadow = (PVOID)CurrentThread->Tcb.ServiceTable;
					SDTFound = TRUE;
					break;
				}
			}
			TCurrentNode = TCurrentNode->Flink;
		}
		if(SDTFound)
			break;
		CurrentNode=CurrentNode->Flink;
	}

	KeReleaseSpinLock(&SpinLock, OldIrql);
	return SDTShadow;
}

BOOL WriteRelativeInconditionalJmp(DWORD AddressToChange, DWORD JumpTo)
{
	DWORD JmpRel;
	BYTE* OpcodeViewByte;
	DWORD* OpcodeViewDword;
	OpcodeViewByte=(BYTE*)AddressToChange;
	*OpcodeViewByte=0xE9;
	*OpcodeViewByte++;
	OpcodeViewDword=(DWORD*)OpcodeViewByte;
	JmpRel=JumpTo-AddressToChange-5;
	*OpcodeViewDword=JmpRel;
	return TRUE;
}


/**********************************************
 *                 MySacrafice                *
 **********************************************/