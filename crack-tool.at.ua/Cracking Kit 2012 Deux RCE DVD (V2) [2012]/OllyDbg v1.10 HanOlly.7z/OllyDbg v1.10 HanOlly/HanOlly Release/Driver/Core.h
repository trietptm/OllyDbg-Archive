NTSTATUS ini();
NTSTATUS unload();


typedef NTSTATUS (NTAPI *TNtQueryInformationProcss)(HANDLE, PROCESSINFOCLASS, PVOID, ULONG, PULONG);
NTSTATUS WINAPI NtQueryInformationProcessHook(HANDLE ProcessHandle, PROCESSINFOCLASS ProcessInformationClass, PVOID ProcessInformation, ULONG ProcessInformationLength, PULONG ReturnLength);