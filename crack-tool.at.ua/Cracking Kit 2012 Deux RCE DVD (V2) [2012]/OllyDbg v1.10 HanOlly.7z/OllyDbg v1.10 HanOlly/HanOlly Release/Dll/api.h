#pragma once

#include <windows.h>
#include "resource.h"

#define OS_XP_SP0	0x1054
#define OS_XP_SP1	0x1055
#define OS_XP_SP2	0x1056

DWORD GetOsVersion();
BOOL loadDriverEx(char* driverName);
void unloadDriverEx(char* driverName);