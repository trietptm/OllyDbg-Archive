//Data Definition
#define NT_SUCCESS(Status) ((NTSTATUS)(Status) >= 0) 
#define STATUS_SUCCESS              0x00000000 
#define STATUS_UNSUCCESSFUL         0xC0000001 
#define STATUS_NOT_IMPLEMENTED      0xC0000002 
#define STATUS_INFO_LENGTH_MISMATCH 0xC0000004 
#define STATUS_INVALID_PARAMETER    0xC000000D 
#define STATUS_ACCESS_DENIED        0xC0000022 
#define STATUS_BUFFER_TOO_SMALL     0xC0000023 
#define OBJ_KERNEL_HANDLE           0x00000200 
#define InitializeObjectAttributes( p, n, a, r, s ) { \
    (p)->Length = sizeof( OBJECT_ATTRIBUTES );          \
    (p)->RootDirectory = r;                             \
    (p)->Attributes = a;                                \
    (p)->ObjectName = n;                                \
    (p)->SecurityDescriptor = s;                        \
    (p)->SecurityQualityOfService = NULL;               \
    } 

#define OBJ_INHERIT             0x00000002L
#define OBJ_PERMANENT           0x00000010L
#define OBJ_EXCLUSIVE           0x00000020L
#define OBJ_CASE_INSENSITIVE    0x00000040L
#define OBJ_OPENIF              0x00000080L
#define OBJ_OPENLINK            0x00000100L
#define OBJ_VALID_ATTRIBUTES    0x000001F2L

#define DEVICE_CONTEXT			0x1
#define REGION					0x4
#define BITMAP					0x5
#define PALETTE					0x8
#define FONT					0xA
#define BRUSH					0x10
#define ENHANCED_METAFILE		0x21
#define PEN						0x30

typedef long NTSTATUS;
typedef LONG KPRIORITY;
typedef HINSTANCE *PHINSTANCE;

typedef struct _STRING {
  USHORT  Length;
  USHORT  MaximumLength;
  PCHAR  Buffer;
} ANSI_STRING, *PANSI_STRING;

typedef enum _EVENT_TYPE {
    NotificationEvent,
    SynchronizationEvent
} EVENT_TYPE, *PEVENT_TYPE;

typedef enum _SHUTDOWN_ACTION {
    ShutdownNoReboot,
    ShutdownReboot,
    ShutdownPowerOff
} SHUTDOWN_ACTION, *PSHUTDOWN_ACTION;


typedef struct _UNICODE_STRING{
  USHORT  Length;
  USHORT  MaximumLength;
  PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _IO_STATUS_BLOCK {
union {
NTSTATUS Status;
PVOID Pointer;
} DUMMYUNIONNAME;
ULONG_PTR Information;
} IO_STATUS_BLOCK, *PIO_STATUS_BLOCK;

typedef void (WINAPI * PIO_APC_ROUTINE)(PVOID,PIO_STATUS_BLOCK,ULONG);

typedef struct _SYSTEM_LOAD_AND_CALL_IMAGE {
  UNICODE_STRING  ModuleName;
} SYSTEM_LOAD_AND_CALL_IMAGE, *PSYSTEM_LOAD_AND_CALL_IMAGE;

typedef enum _SYSTEM_INFORMATION_CLASS{
	SystemInformationClassMin = 0,
	SystemBasicInformation = 0,
	SystemProcessorInformation = 1,
	SystemPerformanceInformation = 2,
	SystemTimeOfDayInformation = 3,
	SystemPathInformation = 4,
	SystemNotImplemented1 = 4,
	SystemProcessInformation = 5,
	SystemProcessesAndThreadsInformation = 5,
	SystemCallCountInfoInformation = 6,
	SystemCallCounts = 6,
	SystemDeviceInformation = 7,
	SystemConfigurationInformation = 7,
	SystemProcessorPerformanceInformation = 8,
	SystemProcessorTimes = 8,
	SystemFlagsInformation = 9,
	SystemGlobalFlag = 9,
	SystemCallTimeInformation = 10,
	SystemNotImplemented2 = 10,
	SystemModuleInformation = 11,
	SystemLocksInformation = 12,
	SystemLockInformation = 12,
	SystemStackTraceInformation = 13,
	SystemNotImplemented3 = 13,
	SystemPagedPoolInformation = 14,
	SystemNotImplemented4 = 14,
	SystemNonPagedPoolInformation = 15,
	SystemNotImplemented5 = 15,
	SystemHandleInformation = 16,
	SystemObjectInformation = 17,
	SystemPageFileInformation = 18,
	SystemPagefileInformation = 18,
	SystemVdmInstemulInformation = 19,
	SystemInstructionEmulationCounts = 19,
	SystemVdmBopInformation = 20,
	SystemInvalidInfoClass1 = 20,	
	SystemFileCacheInformation = 21,
	SystemCacheInformation = 21,
	SystemPoolTagInformation = 22,
	SystemInterruptInformation = 23,
	SystemProcessorStatistics = 23,
	SystemDpcBehaviourInformation = 24,
	SystemDpcInformation = 24,
	SystemFullMemoryInformation = 25,
	SystemNotImplemented6 = 25,
	SystemLoadImage = 26,
	SystemUnloadImage = 27,
	SystemTimeAdjustmentInformation = 28,
	SystemTimeAdjustment = 28,
	SystemSummaryMemoryInformation = 29,
	SystemNotImplemented7 = 29,
	SystemNextEventIdInformation = 30,
	SystemNotImplemented8 = 30,
	SystemEventIdsInformation = 31,
	SystemNotImplemented9 = 31,
	SystemCrashDumpInformation = 32,
	SystemExceptionInformation = 33,
	SystemCrashDumpStateInformation = 34,
	SystemKernelDebuggerInformation = 35,
	SystemContextSwitchInformation = 36,
	SystemRegistryQuotaInformation = 37,
	SystemLoadAndCallImage = 38,
	SystemPrioritySeparation = 39,
	SystemPlugPlayBusInformation = 40,
	SystemNotImplemented10 = 40,
	SystemDockInformation = 41,
	SystemNotImplemented11 = 41,
	/* SystemPowerInformation = 42, Conflicts with POWER_INFORMATION_LEVEL 1 */
	SystemInvalidInfoClass2 = 42,
	SystemProcessorSpeedInformation = 43,
	SystemInvalidInfoClass3 = 43,
	SystemCurrentTimeZoneInformation = 44,
	SystemTimeZoneInformation = 44,
	SystemLookasideInformation = 45,
	SystemSetTimeSlipEvent = 46,
	SystemCreateSession = 47,
	SystemDeleteSession = 48,
	SystemInvalidInfoClass4 = 49,
	SystemRangeStartInformation = 50,
	SystemVerifierInformation = 51,
	SystemAddVerifier = 52,
	SystemSessionProcessesInformation	= 53,
	SystemInformationClassMax
} SYSTEM_INFORMATION_CLASS;

typedef struct _CLIENT_ID{
HANDLE UniqueProcess;
HANDLE UniqueThread;
}CLIENT_ID, *PCLIENT_ID;

typedef struct _VM_COUNTERS {
    SIZE_T	    PeakVirtualSize;
    SIZE_T	    VirtualSize;
    ULONG	    PageFaultCount;
    SIZE_T	    PeakWorkingSetSize;
    SIZE_T	    WorkingSetSize;
    SIZE_T	    QuotaPeakPagedPoolUsage;
    SIZE_T	    QuotaPagedPoolUsage;
    SIZE_T	    QuotaPeakNonPagedPoolUsage;
    SIZE_T	    QuotaNonPagedPoolUsage;
    SIZE_T	    PagefileUsage;
    SIZE_T	    PeakPagefileUsage;
} VM_COUNTERS;

typedef struct _SYSTEM_THREAD_INFORMATION {
    LARGE_INTEGER   KernelTime;
    LARGE_INTEGER   UserTime;
    LARGE_INTEGER   CreateTime;
    ULONG			WaitTime;
    PVOID			StartAddress;
    CLIENT_ID	    ClientId;
    KPRIORITY	    Priority;
    KPRIORITY	    BasePriority;
    ULONG			ContextSwitchCount;
    LONG			State;
    LONG			WaitReason;
} SYSTEM_THREAD_INFORMATION, * PSYSTEM_THREAD_INFORMATION;

// Note, that the size of the SYSTEM_PROCESS_INFORMATION structure is 
// different on NT 4 and Win2K.

typedef struct _SYSTEM_PROCESS_INFORMATION_NT4 {
    ULONG			NextEntryDelta;
    ULONG			ThreadCount;
    ULONG			Reserved1[6];
    LARGE_INTEGER   CreateTime;
    LARGE_INTEGER   UserTime;
    LARGE_INTEGER   KernelTime;
    UNICODE_STRING  ProcessName;
    KPRIORITY	    BasePriority;
    ULONG			ProcessId;
    ULONG			InheritedFromProcessId;
    ULONG			HandleCount;
    ULONG			Reserved2[2];
    VM_COUNTERS	    VmCounters;
    SYSTEM_THREAD_INFORMATION  Threads[1];
} SYSTEM_PROCESS_INFORMATION_NT4, * PSYSTEM_PROCESS_INFORMATION_NT4;

typedef struct _SYSTEM_PROCESS_INFORMATION {
    ULONG			NextEntryDelta;
    ULONG			ThreadCount;
    ULONG			Reserved1[6];
    LARGE_INTEGER   CreateTime;
    LARGE_INTEGER   UserTime;
    LARGE_INTEGER   KernelTime;
    UNICODE_STRING  ProcessName;
    KPRIORITY	    BasePriority;
    ULONG			ProcessId;
    ULONG			InheritedFromProcessId;
    ULONG			HandleCount;
    ULONG			Reserved2[2];
    VM_COUNTERS	    VmCounters;
    IO_COUNTERS	    IoCounters;
    SYSTEM_THREAD_INFORMATION  Threads[1];
} SYSTEM_PROCESS_INFORMATION, * PSYSTEM_PROCESS_INFORMATION;

typedef struct _SYSTEM_MODULE_INFORMATION { 
    ULONG Reserved[2]; 
    PVOID Base; 
    ULONG Size; 
    ULONG Flags; 
    USHORT Index; 
    USHORT Unknown; 
    USHORT LoadCount; 
    USHORT ModuleNameOffset; 
    CHAR ImageName[256]; 
} SYSTEM_MODULE_INFORMATION, *PSYSTEM_MODULE_INFORMATION; 

typedef struct _OBJECT_ATTRIBUTES { 
    ULONG Length; 
    HANDLE RootDirectory; 
    PUNICODE_STRING ObjectName; 
    ULONG Attributes; 
    PVOID SecurityDescriptor; 
    PVOID SecurityQualityOfService; 
} OBJECT_ATTRIBUTES, *POBJECT_ATTRIBUTES; 

typedef enum _SECTION_INHERIT { 
    ViewShare = 1, 
    ViewUnmap = 2 
} SECTION_INHERIT, *PSECTION_INHERIT;

typedef void (*PPEBLOCKROUTINE)(PVOID PebLock); 

typedef struct _RTL_DRIVE_LETTER_CURDIR {
USHORT Flags;
USHORT Length;
ULONG TimeStamp;
UNICODE_STRING DosPath;
} RTL_DRIVE_LETTER_CURDIR, *PRTL_DRIVE_LETTER_CURDIR;

typedef struct _PEB_LDR_DATA {
ULONG Length;
BOOLEAN Initialized;
PVOID SsHandle;
LIST_ENTRY InLoadOrderModuleList;
LIST_ENTRY InMemoryOrderModuleList;
LIST_ENTRY InInitializationOrderModuleList;
} PEB_LDR_DATA, *PPEB_LDR_DATA;

typedef struct _LDR_MODULE {
LIST_ENTRY InLoadOrderModuleList;
LIST_ENTRY InMemoryOrderModuleList;
LIST_ENTRY InInitializationOrderModuleList;
PVOID BaseAddress;
PVOID EntryPoint;
ULONG SizeOfImage;
UNICODE_STRING FullDllName;
UNICODE_STRING BaseDllName;
ULONG Flags;
SHORT LoadCount;
SHORT TlsIndex;
LIST_ENTRY HashTableEntry;
ULONG TimeDateStamp;
} LDR_MODULE, *PLDR_MODULE;

typedef struct _RTL_USER_PROCESS_PARAMETERS {
ULONG MaximumLength;
ULONG Length;
ULONG Flags;
ULONG DebugFlags;
PVOID ConsoleHandle;
ULONG ConsoleFlags;
HANDLE StdInputHandle;
HANDLE StdOutputHandle;
HANDLE StdErrorHandle;
UNICODE_STRING CurrentDirectoryPath;
HANDLE CurrentDirectoryHandle;
UNICODE_STRING DllPath;
UNICODE_STRING ImagePathName;
UNICODE_STRING CommandLine;
PVOID Environment;
ULONG StartingPositionLeft;
ULONG StartingPositionTop;
ULONG Width;
ULONG Height;
ULONG CharWidth;
ULONG CharHeight;
ULONG ConsoleTextAttributes;
ULONG WindowFlags;
ULONG ShowWindowFlags;
UNICODE_STRING WindowTitle;
UNICODE_STRING DesktopName;
UNICODE_STRING ShellInfo;
UNICODE_STRING RuntimeData;
RTL_DRIVE_LETTER_CURDIR DLCurrentDirectory[0x20];
} RTL_USER_PROCESS_PARAMETERS, *PRTL_USER_PROCESS_PARAMETERS;

typedef struct _PEB_FREE_BLOCK {
struct _PEB_FREE_BLOCK *Next;
ULONG Size;
} PEB_FREE_BLOCK, *PPEB_FREE_BLOCK;

typedef struct _GDITableEntry{
   DWORD pKernelInfo;
// 2000/XP layout but these fields are inverted in Windows NT
   WORD  ProcessID; 
   WORD  _nCount;

   WORD  nUpper;
   WORD  nType;
   DWORD pUserInfo;
} GDITableEntry;



typedef struct _PEB {
BOOLEAN InheritedAddressSpace;
BOOLEAN ReadImageFileExecOptions;
BOOLEAN BeingDebugged;
BOOLEAN Spare;
HANDLE Mutant;
PVOID ImageBaseAddress;
PPEB_LDR_DATA LoaderData;
PRTL_USER_PROCESS_PARAMETERS ProcessParameters;
PVOID SubSystemData;
PVOID ProcessHeap;
PVOID FastPebLock;
PPEBLOCKROUTINE FastPebLockRoutine;
PPEBLOCKROUTINE FastPebUnlockRoutine;
ULONG EnvironmentUpdateCount;
PVOID *KernelCallbackTable;
PVOID EventLogSection;
PVOID EventLog;
PPEB_FREE_BLOCK FreeList;
ULONG TlsExpansionCounter;
PVOID TlsBitmap;
ULONG TlsBitmapBits[0x2];
PVOID ReadOnlySharedMemoryBase;
PVOID ReadOnlySharedMemoryHeap;
PVOID *ReadOnlyStaticServerData;
PVOID AnsiCodePageData;
PVOID OemCodePageData;
PVOID UnicodeCaseTableData;
ULONG NumberOfProcessors;
ULONG NtGlobalFlag;
BYTE Spare2[0x4];
LARGE_INTEGER CriticalSectionTimeout;
ULONG HeapSegmentReserve;
ULONG HeapSegmentCommit;
ULONG HeapDeCommitTotalFreeThreshold;
ULONG HeapDeCommitFreeBlockThreshold;
ULONG NumberOfHeaps;
ULONG MaximumNumberOfHeaps;
PVOID **ProcessHeaps;
PVOID GdiSharedHandleTable;
PVOID ProcessStarterHelper;
PVOID GdiDCAttributeList;
PVOID LoaderLock;
ULONG OSMajorVersion;
ULONG OSMinorVersion;
ULONG OSBuildNumber;
ULONG OSPlatformId;
ULONG ImageSubSystem;
ULONG ImageSubSystemMajorVersion;
ULONG ImageSubSystemMinorVersion;
ULONG GdiHandleBuffer[0x22];
ULONG PostProcessInitRoutine;
ULONG TlsExpansionBitmap;
BYTE TlsExpansionBitmapBits[0x80];
ULONG SessionId;
} PEB, *PPEB;

typedef enum _PROCESSINFOCLASS {
     ProcessBasicInformation = 0,
     ProcessQuotaLimits = 1,
     ProcessIoCounters = 2,
     ProcessVmCounters = 3,
     ProcessTimes = 4,
     ProcessBasePriority = 5,
     ProcessRaisePriority = 6,
     ProcessDebugPort = 7,
     ProcessExceptionPort = 8,
     ProcessAccessToken = 9,
     ProcessLdtInformation = 10,
     ProcessLdtSize = 11,
     ProcessDefaultHardErrorMode = 12,
     ProcessIoPortHandlers = 13,
     ProcessPooledUsageAndLimits = 14,
     ProcessWorkingSetWatch = 15,
     ProcessUserModeIOPL = 16,
     ProcessEnableAlignmentFaultFixup = 17,
     ProcessPriorityClass = 18,
     ProcessWx86Information = 19,
     ProcessHandleCount = 20,
     ProcessAffinityMask = 21,
     ProcessPriorityBoost = 22,
     ProcessDeviceMap = 23,
     ProcessSessionInformation = 24,
     ProcessForegroundInformation = 25,
     ProcessWow64Information = 26,
     ProcessImageFileName = 27,
     ProcessLUIDDeviceMapsEnabled = 28,
     ProcessBreakOnTermination = 29,
     ProcessDebugObjectHandle = 30,
     ProcessDebugFlags = 31,
     ProcessHandleTracing = 32,
     MaxProcessInfoClass
} PROCESSINFOCLASS, PROCESS_INFORMATION_CLASS;

typedef enum _THREADINFOCLASS {
     ThreadBasicInformation,
     ThreadTimes,
     ThreadPriority,
     ThreadBasePriority,
     ThreadAffinityMask,
     ThreadImpersonationToken,
     ThreadDescriptorTableEntry,
     ThreadEnableAlignmentFaultFixup,
     ThreadEventPair_Reusable,
     ThreadQuerySetWin32StartAddress,
     ThreadZeroTlsCell,
     ThreadPerformanceCount,
     ThreadAmILastThread,
     ThreadIdealProcessor,
     ThreadPriorityBoost,
     ThreadSetTlsArrayAddress,
     ThreadIsIoPending,
     MaxThreadInfoClass
} THREADINFOCLASS;


//Functions Definition
extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtShutdownSystem(
  IN SHUTDOWN_ACTION	Action 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtCreateProcess(
  OUT PHANDLE           ProcessHandle,
  IN ACCESS_MASK        DesiredAccess,
  IN POBJECT_ATTRIBUTES ObjectAttributes OPTIONAL,
  IN HANDLE             ParentProcess,
  IN BOOLEAN            InheritObjectTable,
  IN HANDLE             SectionHandle OPTIONAL,
  IN HANDLE             DebugPort OPTIONAL,
  IN HANDLE             ExceptionPort OPTIONAL 
  );

extern "C"
NTSYSAPI
VOID 
NTAPI
RtlInitUnicodeString(
    IN OUT PUNICODE_STRING  DestinationString,
    IN PCWSTR				SourceString
    );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtLoadDriver(
  IN PUNICODE_STRING	DriverServiceName 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtQueryInformationProcess(
  IN HANDLE               ProcessHandle,
  IN PROCESS_INFORMATION_CLASS ProcessInformationClass,
  OUT PVOID               ProcessInformation,
  IN ULONG                ProcessInformationLength,
  OUT PULONG              ReturnLength 
  );

extern "C"
NTSYSAPI 
NTSTATUS 
NTAPI 
NtQuerySystemInformation( 
    ULONG SystemInformationClass, 
    PVOID SystemInformation, 
    ULONG SystemInformationLength, 
    PULONG ReturnLength 
    ); 

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtCreateSection(
  OUT PHANDLE             SectionHandle,
  IN ULONG                DesiredAccess,
  IN POBJECT_ATTRIBUTES   ObjectAttributes OPTIONAL,
  IN PLARGE_INTEGER       MaximumSize OPTIONAL,
  IN ULONG                PageAttributess,
  IN ULONG                SectionAttributes,
  IN HANDLE               FileHandle OPTIONAL);

extern "C"
NTSYSAPI 
NTSTATUS 
NTAPI 
NtOpenSection( 
    OUT PHANDLE SectionHandle, 
    IN ACCESS_MASK DesiredAccess, 
    IN POBJECT_ATTRIBUTES ObjectAttributes 
    ); 

extern "C"
NTSYSAPI 
NTSTATUS 
NTAPI 
NtMapViewOfSection( 
    IN HANDLE SectionHandle, 
    IN HANDLE ProcessHandle, 
    IN OUT PVOID *BaseAddress, 
    IN ULONG ZeroBits, 
    IN ULONG CommitSize, 
    IN OUT PLARGE_INTEGER SectionOffset OPTIONAL, 
    IN OUT PULONG ViewSize, 
    IN SECTION_INHERIT InheritDisposition, 
    IN ULONG AllocationType, 
    IN ULONG Protect 
    ); 

extern "C"
NTSYSAPI 
NTSTATUS 
NTAPI 
NtUnmapViewOfSection( 
    IN HANDLE ProcessHandle, 
    IN PVOID BaseAddress 
    ); 

extern "C"
NTSYSAPI 
NTSTATUS 
NTAPI 
NtClose( 
    IN HANDLE Handle 
    ); 

extern "C"
NTSYSAPI 
NTSTATUS 
NTAPI 
NtVdmControl( 
    IN ULONG ControlCode, 
    IN PVOID ControlData 
    ); 

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtOpenProcess(
  OUT PHANDLE             ProcessHandle,
  IN ACCESS_MASK          AccessMask,
  IN POBJECT_ATTRIBUTES   ObjectAttributes,
  IN PCLIENT_ID           ClientId);

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtWriteVirtualMemory(
  IN HANDLE               ProcessHandle,
  IN PVOID                BaseAddress,
  IN PVOID                Buffer,
  IN ULONG                NumberOfBytesToWrite,
  OUT PULONG              NumberOfBytesWritten OPTIONAL);

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtReadVirtualMemory(
  IN HANDLE               ProcessHandle,
  IN PVOID                BaseAddress,
  OUT PVOID               Buffer,
  IN ULONG                NumberOfBytesToRead,
  OUT PULONG              NumberOfBytesReaded OPTIONAL);

extern "C"
NTSYSAPI
NTSTATUS
NTAPI
NtOpenThread(
    OUT PHANDLE pThreadHandle,
    IN ULONG DesiredAccess,
    IN POBJECT_ATTRIBUTES ObjectAttributes,
    IN PCLIENT_ID ClientId
    );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtDeviceIoControlFile(
  IN HANDLE               FileHandle,
  IN HANDLE               Event OPTIONAL,
  IN PIO_APC_ROUTINE      ApcRoutine OPTIONAL,
  IN PVOID                ApcContext OPTIONAL,
  OUT PIO_STATUS_BLOCK    IoStatusBlock,
  IN ULONG                IoControlCode,
  IN PVOID                InputBuffer OPTIONAL,
  IN ULONG                InputBufferLength,
  OUT PVOID               OutputBuffer OPTIONAL,
  IN ULONG                OutputBufferLength 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtFsControlFile(
  IN HANDLE               FileHandle,
  IN HANDLE               Event OPTIONAL,
  IN PIO_APC_ROUTINE      ApcRoutine OPTIONAL,
  IN PVOID                ApcContext OPTIONAL,
  OUT PIO_STATUS_BLOCK    IoStatusBlock,
  IN ULONG                FsControlCode,
  IN PVOID                InputBuffer OPTIONAL,
  IN ULONG                InputBufferLength,
  OUT PVOID               OutputBuffer OPTIONAL,
  IN ULONG                OutputBufferLength 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtCreateMutant(
  OUT PHANDLE             MutantHandle,
  IN ACCESS_MASK          DesiredAccess,
  IN POBJECT_ATTRIBUTES   ObjectAttributes OPTIONAL,
  IN BOOLEAN              InitialOwner 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtOpenProcess(
  OUT PHANDLE             ProcessHandle,
  IN ACCESS_MASK          AccessMask,
  IN POBJECT_ATTRIBUTES   ObjectAttributes,
  IN PCLIENT_ID			  ClientId
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtCreateFile(
  OUT PHANDLE             FileHandle,
  IN ACCESS_MASK          DesiredAccess,
  IN POBJECT_ATTRIBUTES   ObjectAttributes,
  OUT PIO_STATUS_BLOCK    IoStatusBlock,
  IN PLARGE_INTEGER       AllocationSize OPTIONAL,
  IN ULONG                FileAttributes,
  IN ULONG                ShareAccess,
  IN ULONG                CreateDisposition,
  IN ULONG                CreateOptions,
  IN PVOID                EaBuffer OPTIONAL,
  IN ULONG                EaLength 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtCreateEvent(
  OUT PHANDLE             EventHandle,
  IN ACCESS_MASK          DesiredAccess,
  IN POBJECT_ATTRIBUTES   ObjectAttributes OPTIONAL,
  IN EVENT_TYPE           EventType,
  IN BOOLEAN              InitialState 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtOpenEvent(
  OUT PHANDLE             EventHandle,
  IN ACCESS_MASK          DesiredAccess,
  IN POBJECT_ATTRIBUTES   ObjectAttributes 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtProtectVirtualMemory(
  IN HANDLE               ProcessHandle,
  IN OUT PVOID            *BaseAddress,
  IN OUT PULONG           NumberOfBytesToProtect,
  IN ULONG                NewAccessProtection,
  OUT PULONG              OldAccessProtection 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtAllocateVirtualMemory(
  IN HANDLE               ProcessHandle,
  IN OUT PVOID            *BaseAddress,
  IN ULONG                ZeroBits,
  IN OUT PULONG           RegionSize,
  IN ULONG                AllocationType,
  IN ULONG                Protect
  );

extern "C"
NTSYSAPI 
PVOID
NTAPI
RtlAllocateHeap(
  IN PVOID                HeapHandle,
  IN ULONG                Flags,
  IN ULONG                Size 
  );

extern "C"
NTSYSAPI
NTSTATUS 
NTAPI 
RtlUnicodeToMultiByteN(
  PCHAR MbString, 
  ULONG MbSize, 
  PULONG ResultSize, 
  PWCHAR UnicodeString, 
  ULONG UnicodeSize
  ); 

extern "C"
NTSYSAPI
NTSTATUS 
NTAPI  
RtlUnicodeToMultiByteSize(
  PULONG MbSize, 
  PWCHAR UnicodeString, 
  ULONG UnicodeSize
  ); 

extern "C"
NTSYSAPI 
PVOID 
NTAPI 
RtlImageDirectoryEntryToData( 
	HMODULE BaseAddress,  
	BOOL bMappedAsImage,  
	WORD Directory,  
	ULONG* Size
	);  

extern "C"
NTSYSAPI 
VOID 
NTAPI 
RtlInitUnicodeString( 
    PUNICODE_STRING DestinationString, 
    PCWSTR SourceString 
    ); 

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
LdrLoadDll (
    IN PWSTR DllPath OPTIONAL,
    IN PULONG DllCharacteristics OPTIONAL,
    IN PUNICODE_STRING DllName,
    OUT PVOID *DllHandle
    );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtLoadDriver(
  IN PUNICODE_STRING DriverServiceName
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtUnloadDriver(
  IN PUNICODE_STRING DriverServiceName
  );

extern "C"
NTSYSAPI 
NTSTATUS 
NTAPI
RtlAnsiStringToUnicodeString(
  IN OUT PUNICODE_STRING  DestinationString,
  IN PANSI_STRING  SourceString,
  IN BOOLEAN  AllocateDestinationString
  );

extern "C"
NTSYSAPI 
VOID 
NTAPI
RtlFreeUnicodeString(
  IN PUNICODE_STRING  UnicodeString
  );

extern "C"
NTSYSAPI 
VOID 
NTAPI
RtlInitAnsiString(
  IN OUT PANSI_STRING  DestinationString,
  IN PCHAR  SourceString
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtCreateKey(
  OUT PHANDLE             pKeyHandle,
  IN ACCESS_MASK          DesiredAccess,
  IN POBJECT_ATTRIBUTES   ObjectAttributes,
  IN ULONG                TitleIndex,
  IN PUNICODE_STRING      Class OPTIONAL,
  IN ULONG                CreateOptions,
  OUT PULONG              Disposition OPTIONAL 
  );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
NtSetValueKey(
  IN HANDLE               KeyHandle,
  IN PUNICODE_STRING      ValueName,
  IN ULONG                TitleIndex OPTIONAL,
  IN ULONG                Type,
  IN PVOID                Data,
  IN ULONG                DataSize 
  );

extern "C"
NTSYSAPI 
NTSTATUS 
NTAPI 
RtlMultiByteToUnicodeN( 
   LPWSTR dst, 
   DWORD dstlen, 
   LPDWORD reslen,
   LPCSTR src, 
   DWORD srclen 
   );

extern "C"
NTSYSAPI 
NTSTATUS
NTAPI
ZwSetSystemInformation(
  IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
  IN PVOID                SystemInformation,
  IN ULONG                SystemInformationLength 
  );

