#define WIN32_LEAN_AND_MEAN


#include <windows.h> 	
#include <commdlg.h>
#include <commctrl.h>
#include "resource.h"

#define NTSIGNATURE(a) ((LPVOID)((BYTE *)a + ((PIMAGE_DOS_HEADER)a)->e_lfanew)) 
#define MakePtr(Type, Base, Offset) ((Type)(DWORD(Base) + (DWORD)(Offset)))


// prototype des fonctions

BOOL CALLBACK DlgProc( HWND hWnd, UINT uMsg, WPARAM wParam,LPARAM lParam);
BOOL CALLBACK FindProc( HWND hWnd, UINT uMsg, WPARAM wParam,LPARAM lParam);
BOOL open(HWND hwndOwner, char FullPath[MAX_PATH], char FileName[256]);
void ChooseFile(HWND hWnd);
void InitList();
void InitComboDll();
BOOL LoadDll(HWND hWnd);
void ClickDroitList(HWND hWnd, LPARAM lParam);
void CopyIntoClipBoard(HWND hWnd, BOOL type);




// declaration variables globales

HWND hComboDll;
HWND hList;
char sInputFile[MAX_PATH];
int ComboIndex;
char DllName[MAX_PATH];
int IndexMenu;
HINSTANCE Hinstance;
char Fstring[255];
BOOL ClipBoard_Adress;

/////////////////////////////////////////////////////////////////////////////////////////


int APIENTRY WinMain(HINSTANCE hInstance,
					 HINSTANCE hPrevInstance,
					 LPSTR lpCmdLine,
					 int nShowCmd )
{    	
	Hinstance = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,NULL);	   
   	return 0;
}


void CopyIntoClipBoard(HWND hWnd, BOOL type)
{
	// FALSE = function Name
	// TRUE = fnction Address

	char sAdress[255];
	LV_ITEM FAR pitem;
	HGLOBAL hMem;
	LPTSTR  lptstrCopy; 

	pitem.mask = LVIF_TEXT;
	pitem.pszText = sAdress;
	pitem.cchTextMax = 255;

	if (type == TRUE) 
		pitem.iSubItem = 1;	// l'adresse	
	else	
		pitem.iSubItem = 0;	// le nom 

	SendMessage(hList,LVM_GETITEMTEXT,SendMessage(hList,LVM_GETNEXTITEM,-1,LVNI_SELECTED),(LPARAM)&pitem);
	
	// Alloue un bloc de memoire pour le presse papier
				
	hMem = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT,255);
	lptstrCopy = (LPTSTR)GlobalLock(hMem);
	lstrcpy(lptstrCopy,sAdress);				
	

	// ouvre et vide le clipboard
				
	OpenClipboard(hWnd);
	EmptyClipboard();

	// Copie le text dans le presse papier
				
	SetClipboardData(CF_TEXT, hMem);
	CloseClipboard();
	GlobalUnlock(hMem);
	GlobalFree(hMem);

}


BOOL CALLBACK DlgProc( HWND hWnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
	switch (uMsg)
	{
   	case WM_CLOSE:
		EndDialog(hWnd,0); 
		break;
		
	case WM_INITDIALOG:		
		hComboDll = GetDlgItem(hWnd,IDC_COMBO1);			
		hList = GetDlgItem(hWnd,IDC_LIST_LOG);
		InitList();
		InitComboDll();
		break;
		
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{  		
		case IDC_BUTTON_CHOOSE_DLL:
			ChooseFile(hWnd);			
			break;	
			
		case IDM_FIND:
			HWND h2wnd;
			h2wnd = CreateDialog(Hinstance,MAKEINTRESOURCE(IDD_DIALOG2),hWnd,FindProc);
			ShowWindow(h2wnd, SW_SHOW);
			break;
			
		case IDM_COPY_ADRESS:
			CopyIntoClipBoard(hWnd,TRUE);			
			break;
			
		case IDM_COPY_NAME:
			CopyIntoClipBoard(hWnd,FALSE);
			break;
		}
		
		// selection dans le combo box
		
		if (HIWORD(wParam) == CBN_SELCHANGE)
		{
			SendMessage(hList,LVM_DELETEALLITEMS,0,0);
			ComboIndex = SendMessage(hComboDll,CB_GETCURSEL,0,0);
			SendMessage(hComboDll,CB_GETLBTEXT,(WPARAM)SendMessage(hComboDll,CB_GETCURSEL,0,0),(LPARAM)DllName);
			LoadDll(hWnd);
		}
		
		case WM_NOTIFY:
			LPNMHDR nmhdr;
			nmhdr = (LPNMHDR)lParam;
			
			try	{
				if (nmhdr->hwndFrom == hList)
					if (nmhdr->code == NM_RCLICK)
						ClickDroitList(hWnd,lParam);}		
			catch(...){}		
			break;
			
			
		default:
			return FALSE;
	}
	
	return TRUE;
}



void ClickDroitList(HWND hWnd, LPARAM lParam)
{		
	IndexMenu = SendMessage(hList,LVM_GETNEXTITEM,-1,LVNI_SELECTED);
	
	if (IndexMenu != -1) // si en dehors d'un item on affiche pas le menu
	{					
		HMENU menu;
		menu= CreatePopupMenu();
		
		AppendMenu(menu,MF_STRING,IDM_FIND,"Find");		
		AppendMenu(menu,MF_SEPARATOR,0,0);
		AppendMenu(menu,MF_STRING,IDM_COPY_NAME,"Copy Function Name");				
		AppendMenu(menu,MF_STRING,IDM_COPY_ADRESS,"Copy Function Address");
		
		// appelle le menu contextuel
		
		POINT pt;
		GetCursorPos(&pt);                 	 
		TrackPopupMenu(menu,NULL,pt.x,pt.y,NULL,hWnd,NULL);
		DestroyMenu(menu);		
	}	
}


void ChooseFile(HWND hWnd)
{
	char sInputName[MAX_PATH];
	lstrcpy(sInputFile,"\0");
	
	if (open(hWnd,sInputFile,sInputName) == TRUE)
	{
		lstrcpy(DllName,sInputName);
		SendMessage(hList,LVM_DELETEALLITEMS,0,0);
		LoadDll(hWnd);		
		SendMessage(hComboDll,WM_SETTEXT,0,(LPARAM)DllName);
	}	
}




BOOL open(HWND hwndOwner,char FullPath[MAX_PATH], char FileName[256]) 
{ 
	OPENFILENAME ofn;					
	ZeroMemory(&ofn, sizeof(ofn));	
	
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwndOwner;
	ofn.lpstrFilter = "DLL\0*.dll\0All Files\0*.*\0\0";
	ofn.lpstrFile = FullPath;
	ofn.nMaxFile = MAX_PATH; 
	ofn.nMaxFileTitle = 256;
	ofn.lpstrFileTitle = FileName;
	ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY ;
	
	if (GetOpenFileName(&ofn) != 0)
		return TRUE;
	else
		return FALSE;		
	
}


void InitList()	
{	
	int iCol;			
	LV_COLUMN  pcol;	
	
	iCol=0;
	pcol.cx = 200;						
	pcol.mask = LVCF_TEXT|LVCF_WIDTH ;						  
	
	pcol.pszText="Functions";
	SendMessage(hList,LVM_INSERTCOLUMN,(WPARAM) iCol, (LPARAM) &pcol);
	
	iCol=1;
	pcol.cx = 100;
	pcol.pszText="Address";
	SendMessage(hList,LVM_INSERTCOLUMN,(WPARAM) iCol, (LPARAM) &pcol);		
}



void InitComboDll()
{
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"KERNEL32.dll"); 
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"USER32.dll");
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"GDI32.dll");	
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"SHELL32.dll");
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"ADVAPI32.dll");
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"COMCTL32.dll");
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"COMDLG32.dll");
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"CRTDLL.dll");
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"MSVBVM50.dll");
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"MSVBVM60.dll");
	SendMessage(hComboDll,CB_ADDSTRING,0,(LPARAM) (LPCTSTR)"MSVCRT.dll");	
}



BOOL LoadDll(HWND hWnd)
{
	HMODULE hModule = NULL;
	char ss[255];
	LV_ITEM FAR pitem;	
	
	try
	{
		hModule = LoadLibrary(DllName);		
		
		if (hModule == NULL)
		{
			MessageBox(hWnd,"Error Load DLL","Error",MB_OK);
			return FALSE;
		}
		
		PIMAGE_DOS_HEADER pDOSHead;
		pDOSHead = (PIMAGE_DOS_HEADER)hModule; 
		
		if ( pDOSHead->e_magic != IMAGE_DOS_SIGNATURE ) 
		{
			MessageBox(hWnd,"Not correct PE-File","Error",MB_OK);
			return FALSE;
		}
		
		PIMAGE_NT_HEADERS pPEHeader;
		pPEHeader=(PIMAGE_NT_HEADERS) NTSIGNATURE(pDOSHead);
		
		if ( pPEHeader->Signature != IMAGE_NT_SIGNATURE ) 
		{
			MessageBox(hWnd,"Not correct PE-File","Error",MB_OK);
			return FALSE; 
		}
		
		IMAGE_FILE_HEADER FileHeader;
		FileHeader=(IMAGE_FILE_HEADER) pPEHeader->FileHeader; 
		
		if (FileHeader.Machine!=IMAGE_FILE_MACHINE_I386)
		{
			MessageBox(hWnd,"Not correct PE-File","Error",MB_OK);
			return FALSE; 
		}
		
		IMAGE_OPTIONAL_HEADER32 OptionHeader;
		OptionHeader=(IMAGE_OPTIONAL_HEADER32) pPEHeader->OptionalHeader; 
		
		PIMAGE_EXPORT_DIRECTORY pImportDesc = NULL; 
		pImportDesc = MakePtr(PIMAGE_EXPORT_DIRECTORY,hModule,pPEHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress);
		
		PCSTR *l_ppszName = MakePtr(PCSTR*,pImportDesc->AddressOfNames, hModule);
		DWORD x = pImportDesc->NumberOfNames; 
		
		pitem.mask = LVIF_TEXT;		
		
		for (DWORD i=0;i<x;i++)
		{
			char *p=MakePtr(char*,*l_ppszName,hModule);	
			
			// recup nom de la fonction
			
			pitem.pszText = p;
			pitem.iItem = i;
			pitem.iSubItem = 0;		
			SendMessage(hList,LVM_INSERTITEM,0,(WPARAM)&pitem);

			// recup adresse de la fonction
			
			wsprintf(ss,"%X",GetProcAddress(hModule,p));	
			pitem.pszText = ss;		
			pitem.iSubItem = 1;		
			SendMessage(hList,LVM_SETITEM,0,(WPARAM)&pitem);
			
			l_ppszName++;
		}
		
		FreeLibrary(hModule);
		
		return TRUE;
	}
	catch(...)
	{
		MessageBox(hWnd,"ACCESS MODULE MEMORY ERROR","Error",MB_OK);
		return FALSE;
	}
}



BOOL CALLBACK FindProc( HWND hWnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{
	switch (uMsg)
	{
   	case WM_CLOSE:
		EndDialog(hWnd,0); 
		break;
		
	case WM_INITDIALOG:
		SendMessage(GetDlgItem(hWnd,IDC_RADIO1),BM_SETCHECK,BST_CHECKED,0);
		SetFocus(GetDlgItem(hWnd,IDC_EDIT1));
		return FALSE;
		
		
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			if (GetDlgItemText(hWnd,IDC_EDIT1,Fstring,255) == 0)			
				MessageBox(hWnd,"Enter a value, please","GPA",0);
			else
			{				
				if (SendMessage(GetDlgItem(hWnd,IDC_RADIO2),BM_GETCHECK,0,0))
				{
					// cherche by Name
					
					LVFINDINFO plvfi;					
					int n;					
					
					plvfi.flags = LVFI_PARTIAL;
					plvfi.psz = Fstring;				
					
					n = SendMessage(hList,LVM_FINDITEM,-1,(LPARAM)(LV_FINDINFO*)&plvfi);
					
					if (n == -1) 
						MessageBox(hWnd,"Name not Found","GPA",0);
					else
					{
						ListView_SetItemState(hList, n, LVIS_SELECTED, LVIS_SELECTED);						
						SendMessage(hList,LVM_ENSUREVISIBLE,n,TRUE);
						SendMessage(hWnd,WM_CLOSE,0,0);
					}
					
				}
				else
				{
					// cherche by address
					
					char sAdress[255];
					LV_ITEM FAR pitem;
					int n = 0;
					int x;					
					
					x = SendMessage(hList,LVM_GETITEMCOUNT,0,0);					
					_strupr(Fstring);										
					
					pitem.mask = LVIF_TEXT;
					pitem.iSubItem = 1;
					pitem.pszText = sAdress;
					pitem.cchTextMax = 255;					
					
					while (n <= x ) 
					{
						SendMessage(hList,LVM_GETITEMTEXT,n,(LPARAM)&pitem);
						if (lstrcmp(Fstring,sAdress) == 0) 
							break;
						n++;
					}
					
					if (n > x) 					
						MessageBox(hWnd,"Address not Found","GPA",0);					
					else
					{
						ListView_SetItemState(hList, n, LVIS_SELECTED, LVIS_SELECTED);						
						SendMessage(hList,LVM_ENSUREVISIBLE,n,TRUE);
						SendMessage(hWnd,WM_CLOSE,0,0);
					}
				}
			}
			break;
		}
		
		default:
			return FALSE;
	}
	
	return TRUE;
}
