#include "main.h"

bool init_done=false;

//dummy export (for easy usage of the DLL)
//add this to import table of OllyDbg.exe
//to make this tool work.
void DLL_EXPORT dummy(void)
{
    return;
}

void OllyINI(void)
{
    //Variable declarations
    char ini_file[256]="";
    char ida_sigs_ini[256]="";
    char olly_flow_ini[256]="";

    char olly_path[256]="";
    char udd_path[256]="";
    char plug_path[256]="";
    char hlp_path[256]="";
    char mnhlp_path[256]="";

    char ollyjs_path[256]="";
    char dumpsig_path[256]="";
    char wingraph_path[256]="";

    //Get path of ollydbg.exe (as process)
    int i=GetModuleFileNameA(GetModuleHandle(0), olly_path, 256);
    while(olly_path[i]!='\\')
        i--;
    olly_path[i]=0;

    //Get the ini file path
    sprintf(ini_file, "%s\\ollydbg.ini", olly_path);

    //Fill variables with the correct values
    sprintf(udd_path, "%s\\UDD", olly_path);
    sprintf(plug_path, "%s\\Plugins", olly_path);
    sprintf(hlp_path, "%s\\win32.hlp", olly_path);

    sprintf(ida_sigs_ini, "%s\\ida_sigs.ini", plug_path);
    sprintf(olly_flow_ini, "%s\\OllyFlow.ini", plug_path);

    sprintf(ollyjs_path, "%s\\ollydbg.js", olly_path);
    sprintf(dumpsig_path, "%s\\dumpsig.exe", olly_path);
    sprintf(wingraph_path, "%s\\wingraph32.exe", olly_path);
    sprintf(mnhlp_path, "%s\\x86eas.hlp", olly_path);

    //Create the UDD directory
    CreateDirectoryA(udd_path, 0);

    //Write paths to the ini file
    WritePrivateProfileStringA("History", "Symbolic data path", olly_path, ini_file);
    WritePrivateProfileStringA("History", "UDD path", udd_path, ini_file);
    WritePrivateProfileStringA("History", "Plugin path", plug_path, ini_file);
    WritePrivateProfileStringA("History", "API help file", hlp_path, ini_file);

    //Plugin abolute paths
    WritePrivateProfileStringA("Plugin ODBJScript", "Global Header", ollyjs_path, ini_file);
    WritePrivateProfileStringA("Plugin MnemonicHelp", "opcode_help_file", mnhlp_path, ini_file);

    //Other INI absolute paths
    WritePrivateProfileStringA("settings", "ini_dumpsig_path", dumpsig_path, ida_sigs_ini);
    WritePrivateProfileStringA("Options", "WinGraph Path", wingraph_path, olly_flow_ini);
}

extern "C" BOOL APIENTRY DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    //Only set paths once.
    if(!init_done)
    {
        init_done=true;
        OllyINI();
    }
    return true;
}
